# TRIVORTEX MASTER v2.0.3-jl — single-file Julia edition

Лабораторный комплекс задачи N тел: хореографии, вихри Кирхгофа,
планетная динамика, постньютон, анализ данных, отчёты 10 форматов.
Порт однофайлового Python-издания v2.0.3 (73 режима, каталог 538
объектов, 20 пресетов, selftest S1–S24, приёмка A1–A20).

## Запуск

    julia trivortex_master_single.jl                       # интерактивное меню (73 режима)
    julia trivortex_master_single.jl --selftest            # структурные тесты S1–S24
    julia trivortex_master_single.jl --acceptance          # приёмка A1–A20
    julia trivortex_master_single.jl --gate                # полный CI-гейт
    julia trivortex_master_single.jl --banner-only
    julia trivortex_master_single.jl --profile quick --preset inner_solar --simulate --render
    julia trivortex_master_single.jl --preset earth_moon --steps 500 --report
    julia trivortex_master_single.jl --selftest --quiet
    julia trivortex_master_single.jl --version

Требуется Julia 1.10+ и ТОЛЬКО стандартная библиотека (stdlib-first).
Опционально: ffmpeg в PATH — MP4-сборка кадров (без него — честный
fallback-протокол в events сцены, как в Python без imageio).

## Профили

| профиль   | dt     | шагов | смягчение | отчёты                                   |
|-----------|--------|-------|-----------|------------------------------------------|
| quick     | 0.01   | 100   | 1e-3      | md, json                                 |
| standard  | 0.005  | 2000  | 1e-4      | md, html, json, csv                      |
| precision | 0.001  | 5000  | 1e-6      | txt, md, html, csv, json, docx, pdf      |
| demo      | 0.005  | 400   | 1e-4      | txt, md, html, csv, json, docx, pdf, odt |

Флаг `--allow-unphysical` разрешает N=8 (порог Хавелока) с пометкой
сцены unphysical_flag=True и записью события в протокол; N=9 — жёсткий
отказ всегда.

## Структура (портированные модули Python-издания)

- **core**: config, registry (73 режима в 11 категориях), jsonmini
- **lab**: body, scene, units, integrators (RK4/leapfrog/Yoshida-4),
  engines (newton/vortex/Barnes-Hut), kepler+lambert, orbital_maneuvers,
  trajectory+choreography (Теорема 3.1), halo_orbits (CR3BP), trojan_points,
  resonances, tissot, tides, radiation, relativity (1PN/2PN/ISCO/LT),
  chaos (FLI/Пуанкаре/Ласкар), collisions, hamiltonian_split, grid_fields,
  spacecraft (кватернионы/ПИД/маховики), nbody_tree, presets
- **analysis**: lomb_scargle, ttvs, bls, wavelets, fitting (LM), mcmc (R̂),
  entropy, lightcurves, proper_elements, rmt, orbital_elements_fit,
  benchmark B1–B8, api_reference, tests S1–S24
- **realism**: planetary_systems, stellar, almanac, sky_coordinates,
  bright_stars (25, Hipparcos), eclipse_predictor, cosmology ΛCDM,
  encounter, mission_design, space_weather, observatory, jpl_horizons
  (offline-almanac fallback), adapters (rebound/dedalus → events)
- **render**: png/gif кодеки (свой LZW), font_5x7, pure_raster (z-буфер),
  raytracer (Фонг+тени+отражения), camera, particles, ascii_sky, spectrum,
  animator (GIF/MP4), backend_ascii, banners, hud
- **reports**: engine (10 форматов: txt/md/html/csv/json/docx/odt/pdf/
  pptx/xlsx — нативные ZIP+XML), charts (SVG), bibliography, templates
- **tools**: data_exporter, release_notes, verify_package (ZIP+manifest),
  quality_gate (A1–A20)

## Selftest и приёмка

    S1–S12  — структура: пресеты, сериализация, реестр, интегралы Кирхгофа,
              энергия, движки, Теорема 3.1, рендер, отчёты, лимит N
    S13–S24 — физика: Меркурий 42.98″/век, Barnes-Hut, FLI, столкновения,
              Луна 3.8 см/год, ПР-драг, TRAPPIST-1e 249 К, звёзды/Рош,
              xlsx/pptx, MCMC R̂<1.1, вейвлеты+LM
    A1–A20  — приёмка: запуск, N-диапазон, бэкенды, GIF/MP4, отчёты 7/8
              форматов, каталог≥200/520, fallback-протокол, ZIP+manifest,
              README, Меркурий, BH, рейтрейсер, MCMC, Horizons, бенчмарк,
              API ≥65 модулей, меню ≥49, объём исходника

## Источники данных

Каталог (538 объектов) и пресеты встроены в файл (raw-константы,
материализуются при старте через собственный JSONMini-парсер) —
эквивалент gzip+base64 блобов Python-издания. Кэш экзопланет NASA
TAP также встроен; Horizons работает в offline-almanac режиме.
